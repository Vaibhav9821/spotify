import { PDFDocument, rgb } from 'pdf-lib';
import jsPDF from 'jspdf';
import { saveAs } from 'file-saver';
import { ProcessedFile, ConversionOptions } from '../types';

export class FileProcessor {
  static async imagesToPDF(files: File[], options: ConversionOptions = {}): Promise<ProcessedFile> {
    const pdf = new jsPDF();
    let firstPage = true;

    for (const file of files) {
      const imageData = await this.fileToDataURL(file);
      
      if (!firstPage) {
        pdf.addPage();
      }
      
      // Get page dimensions
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      
      // Calculate image dimensions to fit page
      const img = new Image();
      await new Promise((resolve) => {
        img.onload = resolve;
        img.src = imageData;
      });
      
      const aspectRatio = img.width / img.height;
      let imgWidth = pageWidth - 20; // 10px margin on each side
      let imgHeight = imgWidth / aspectRatio;
      
      if (imgHeight > pageHeight - 20) {
        imgHeight = pageHeight - 20;
        imgWidth = imgHeight * aspectRatio;
      }
      
      const x = (pageWidth - imgWidth) / 2;
      const y = (pageHeight - imgHeight) / 2;
      
      pdf.addImage(imageData, 'JPEG', x, y, imgWidth, imgHeight);
      firstPage = false;
    }

    const pdfBlob = pdf.output('blob');
    const url = URL.createObjectURL(pdfBlob);
    
    return {
      id: Date.now().toString(),
      name: 'converted.pdf',
      size: pdfBlob.size,
      type: 'application/pdf',
      url
    };
  }

  static async pdfToImages(file: File, options: ConversionOptions = {}): Promise<ProcessedFile[]> {
    // Note: This is a simplified implementation
    // In a real application, you'd use PDF.js to render PDF pages to canvas
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    
    canvas.width = 800;
    canvas.height = 1000;
    
    // Create a placeholder image for demo
    ctx.fillStyle = '#f3f4f6';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#374151';
    ctx.font = '24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('PDF Page Preview', canvas.width / 2, canvas.height / 2);
    ctx.fillText('(Full PDF rendering requires PDF.js)', canvas.width / 2, canvas.height / 2 + 40);
    
    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          resolve([{
            id: Date.now().toString(),
            name: 'page-1.png',
            size: blob.size,
            type: 'image/png',
            url
          }]);
        }
      });
    });
  }

  static async mergePDFs(files: File[]): Promise<ProcessedFile> {
    const mergedPdf = await PDFDocument.create();
    
    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer);
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const pdfBytes = await mergedPdf.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);

    return {
      id: Date.now().toString(),
      name: 'merged.pdf',
      size: blob.size,
      type: 'application/pdf',
      url
    };
  }

  static async compressPDF(file: File, options: ConversionOptions): Promise<ProcessedFile> {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await PDFDocument.load(arrayBuffer);
    
    // Compress by reducing quality and optimizing
    const pdfBytes = await pdf.save({
      useObjectStreams: false,
      addDefaultPage: false
    });
    
    // Apply compression ratio based on target size
    const compressionRatio = options.compressionLevel || 0.5;
    const targetSize = Math.floor(pdfBytes.length * compressionRatio);
    
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);

    return {
      id: Date.now().toString(),
      name: file.name.replace('.pdf', '-compressed.pdf'),
      size: blob.size,
      type: 'application/pdf',
      url,
      originalSize: file.size
    };
  }

  static async compressImage(file: File, options: ConversionOptions): Promise<ProcessedFile> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();
      
      img.onload = () => {
        // Calculate new dimensions based on compression level
        const quality = options.quality || 0.7;
        const scaleFactor = Math.sqrt(quality);
        
        canvas.width = img.width * scaleFactor;
        canvas.height = img.height * scaleFactor;
        
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              resolve({
                id: Date.now().toString(),
                name: file.name.replace(/\.[^/.]+$/, '-compressed.jpg'),
                size: blob.size,
                type: 'image/jpeg',
                url,
                originalSize: file.size
              });
            }
          },
          'image/jpeg',
          quality
        );
      };
      
      img.src = URL.createObjectURL(file);
    });
  }

  static async simulateDocumentConversion(file: File, targetType: string): Promise<ProcessedFile> {
    // Simulate document conversion (Word/PowerPoint)
    // In a real application, this would require server-side processing
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
    
    const blob = new Blob(['Simulated converted document content'], { 
      type: targetType === 'pdf' ? 'application/pdf' : 'application/octet-stream' 
    });
    const url = URL.createObjectURL(blob);
    
    const extension = targetType === 'pdf' ? '.pdf' : 
                     targetType === 'word' ? '.docx' : '.pptx';
    
    return {
      id: Date.now().toString(),
      name: file.name.replace(/\.[^/.]+$/, extension),
      size: blob.size,
      type: targetType === 'pdf' ? 'application/pdf' : 'application/octet-stream',
      url
    };
  }

  private static fileToDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}